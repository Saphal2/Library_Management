import Model.Books;
import Model.Order;
import Model.User;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Books b1= new Books("Novel", "Sa", "HI", 120, 11);
        Books b2= new Books("PoemCollection", "n", "time", 400, 12);
        Books b3= new Books("Novel", "Non fiction", "Three Cups of tree", 2500, 13);
        Books b4= new Books("Magazine", "non fiction", "Bazar", 1000, 14);
        ArrayList<Books> booksArrayList1 = new ArrayList<>();
        ArrayList<Books> booksArrayList2 = new ArrayList<>();
        booksArrayList1.add(b1);
        booksArrayList1.add(b2);
        booksArrayList2.add(b3);
        booksArrayList2.add(b4);
        User u1= new User("Saphal Sapkota", 1, booksArrayList1);
        User u2= new User("Prayush Shrestha", 2, booksArrayList2);
        ArrayList<User> us1 = new ArrayList<>();
        ArrayList<User> us2 = new ArrayList<>();
        us1.add(u1);
        us2.add(u2);
        Order o1=new Order(11, us1);
        Order o2=new Order(12, us2);
        o1.listUser();
        b1.getInfo();
        b2.getInfo();

        o2.listUser();
        b3.getInfo();
        b4.getInfo();



    }
}